package com.prolifics.websocket;

public class TraceMessengerSink extends Messenger implements TraceMessengerInterface{

	public TraceMessengerSink(String url) {
		super(url);
		setDecoder(new TraceMessageDecoder());
		setEncoder(new TraceMessageEncoder());
	}
	public void sendTraceMessage(String jsonTraceMessage){
		sendAsyncMessage(jsonTraceMessage);
	}
}

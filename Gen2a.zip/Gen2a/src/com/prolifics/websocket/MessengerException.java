package com.prolifics.websocket;

// public class MessengerException extends RuntimeException {
public class MessengerException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MessengerException() {
	}

	public MessengerException(String message) {
		super(message);
	}

	public MessengerException(Throwable cause) {
		super(cause);
	}

	public MessengerException(String message, Throwable cause) {
		super(message, cause);
	}

	public MessengerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}

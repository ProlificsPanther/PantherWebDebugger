package com.prolifics.websocket;

import java.io.IOException;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;

import javax.websocket.Session;

public class Multicast {

	Hashtable<Session, Channel> mapBySession;
	Hashtable<String,Channel> mapById;

	public Multicast() {
		mapBySession = new Hashtable<Session,Channel>();
		mapById = new Hashtable<String,Channel>();
	}

	public Channel getChannel(Session session) {
		return mapBySession.get(session);
	}
	
	public Channel getChannel(String id) {
		return mapById.get(id);
	}
	
	public void closeChannel(Channel channel) {
		Iterator<Session> it = channel.iterator();
		while (it.hasNext()) {
			Session session = it.next();
			try {
				session.close();
				removeSession(session);
			} catch (IOException e) {
				;	// nothing to do
			}	
		}
		
	}
	
	public Multicast.Channel addSession(String id, Session session) {
		Channel ch = mapById.get(id);
		if (ch == null) {
			ch = new Channel(id);
			mapById.put(id, ch);
			mapBySession.put(session, ch);
		}
		ch.addSession(session);
		return ch;
	}
	
	public Multicast.Channel removeSession(Session session) {
		Channel ch = mapBySession.get(session);
		if (ch == null) {
			return null;
		}
		String id = ch.getId();
		ch.removeSession(session);

		if (ch.isEmpty()) {
			mapById.remove(id);
			mapBySession.remove(session);
			return null;
		}
		return ch;
	}
	
	public class Channel {
		private String id;
		private HashSet<Session> sessions;

		public Channel(String id) {
			this.id = id;
			sessions = new HashSet<Session>();
		}

		public synchronized String getId() {
			return id;
		}

		public synchronized void setId(String id) {
			this.id = id;
		}

		public synchronized void addSession(Session session) {
			sessions.add(session);
		}
		
		public synchronized void removeSession(Session session) {
			sessions.remove(session);
		}
		
		public synchronized Iterator<Session> iterator() {
			@SuppressWarnings("unchecked")
			HashSet<Session> clone = (HashSet<Session>)sessions.clone();
			return clone.iterator();
		}
		
		public synchronized int size() {
			return sessions.size();
		}
		
		public synchronized boolean isEmpty() {
			return sessions.isEmpty();
		}
	}
}

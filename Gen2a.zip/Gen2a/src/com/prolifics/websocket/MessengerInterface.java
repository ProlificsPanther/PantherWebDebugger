package com.prolifics.websocket;

public interface MessengerInterface {
	public void openConnection (String endpoint, String channelId);
	public void closeConnection();
	public GenericMessageInterface sendSyncMessage(String message);
	public GenericMessageInterface sendSyncMessage(GenericMessageInterface message);
	public void sendAsyncMessage(String message);
	public void sendAsyncMessage(GenericMessageInterface messagee);
}

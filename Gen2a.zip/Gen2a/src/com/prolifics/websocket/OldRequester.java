package com.prolifics.websocket;

/*************************************/
/*  Copyright  (C)  2017	         */
/*           by                      */
/*  Prolifics, Incorporated	         */
/*  New York, New York               */
/*  All Rights Reserved              */
/*  Printed in U.S.A.                */
/*  Confidential, Unpublished        */
/*  Property of Prolifics, Inc.	     */
/*************************************/

/* %W% %E% %U% */

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.prolifics.servlet.*;


/**
 *
 * @version		 @(#)filtered.java	77.3 13/10/29 16:54:07
 * @author		 Prolifics
 */
@WebServlet("/OldRequester/*")
public
class OldRequester extends ProlificsHttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private static final String sccsid = "%W% %E% %U%";

	public OldRequester() {
    	super();
    }
	
	class SampleFilterHttpServletRequest
		extends FilterHttpServletRequest
	{
		private HttpServletRequest req;
		
		public SampleFilterHttpServletRequest(HttpServletRequest req)
		{
			super(req);
			this.req = req;
		}

		public ServletInputStream getInputStream() throws IOException
		{
			ServletInputStream in = super.getInputStream();
			in = new FilterServletInputStream(in);
			return in;
		}

		/* you can override any portion of the request here */
		
		/* Panther's FilterHttpServletRequest class fails to implement getRequesURL,
		 * so we do it here.
		 * */
		public StringBuffer getRequestURL() {
			return req.getRequestURL();
		}
	}

	private class SampleFilterHttpServletResponse
		extends FilterHttpServletResponse
	{
		ServletOutputStream out = null;
		@SuppressWarnings("unused")
		HttpServletResponse res;
		
		public SampleFilterHttpServletResponse(HttpServletResponse res)
		{
			super(res);
			this.res = res;
		}

		public ServletOutputStream getOutputStream() throws IOException
		{
			if (out == null) {
				out = super.getOutputStream();
				out = new FilterServletOutputStream(out);
			}
			return out;
		}

		/* you can override any portion of the response here */
	}

	public void doGet (HttpServletRequest req,
		HttpServletResponse res)
		throws ServletException, IOException
	{
		req = new SampleFilterHttpServletRequest(req);
		res = new SampleFilterHttpServletResponse(res);
		if (doDebugger(req, res)) {
			return;
		}
		super.doGet(req, res);
	}

	public void doPost (HttpServletRequest req,
		HttpServletResponse res)
		throws ServletException, IOException
	{
		req = new SampleFilterHttpServletRequest(req);
		res = new SampleFilterHttpServletResponse(res);
		if (doDebugger(req, res)) {
			return;
		}
		super.doPost(req, res);
	}
	
	private boolean doDebugger(HttpServletRequest req,
		HttpServletResponse res) 
		throws ServletException, IOException
	{
		String webSocketURL = "ws://" + req.getServerName() + ":" +
				req.getServerPort() + req.getContextPath() + "/websocketendpoint";
		
		/* Set cookies for the response.  These will get sent to
		 * Panther when the iframe makes its request
		 */
		res.addCookie(new Cookie("WebSocketURL", webSocketURL));
		req.getSession();
		
		String pathinfo = req.getPathInfo();
		if (pathinfo == null || !pathinfo.startsWith("/debug/")) {
			return false;
		}
		String url = req.getRequestURL().toString();
		if (url == null) {
			System.out.println("url is null");;
		}
		int ipathinfo = url.indexOf(pathinfo);

		url = url.substring(0, ipathinfo) + url.substring(ipathinfo + 6);
		String queryString = req.getQueryString();
		if (queryString != null) {
			url += queryString;
		}
		// Generate HTML and Javascript

		String script = 
			"$(document).ready(function(){\n" +
					"openSocket('" + req.getSession().getId() + "', '" + webSocketURL + "');\n" +			        	
					"});\n";
		String html = 
//			"<!DOCTYPE html>\n" +
			"<html>\n" +
				"<head>\n" +
				"<link rel=\"stylesheet\" href=\"../../../debugclient.css\">\n" +
				"<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>\n" +
					"<script>\n" +
						script +
					"</script>\n" +
					"<script src=\"../../../debugclient.js\"></script>\n" +
				"</head>\n" +
			
				"<body>\n" +
					"<div id=\"debugUI\">\n" +
						"<div>\n"  +
							"<button type=\"button\" onclick=\"sendNext();\" >Next Event</button>\n" +
						"</div>\n" +
						"<textarea disabled id=\"events\">Debugger Started\n</textarea>\n" +
					"</div>\n" +
					"<div>\n" +	
					"<iframe id=\"pantherframe\" src=" +
						"\"" + url + "\"" +
						">\n" +
						"<p>Your browser does not support iframes.</p>\n" +
					"</iframe>\n" +
					"</div>" +
				"</body>\n" +
			"</html>\n";

		res.getOutputStream().println(html);
		return true;
	}
}

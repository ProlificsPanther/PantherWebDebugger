package com.prolifics.websocket;

import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonObject;
import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;

public class GenericMessageDecoder implements Decoder.Text<GenericMessageInterface> {
	@Override
	public GenericMessageInterface decode(String jsonMessage) throws DecodeException {
		System.out.println("GenericMessageDecoder: " + jsonMessage);
		JsonObject jsonObject = Json
				.createReader(new StringReader(jsonMessage)).readObject();
		GenericMessageInterface message = new GenericMessage();
		message.setChannelId(jsonObject.getString("channelId"));
		message.setMessageType(jsonObject.getInt("messageType"));
		message.setSubject(jsonObject.getString("subject"));
		message.setContent(jsonObject.getString("content"));

		System.out.println("decoded");
		return message;

	}

	@Override
	public boolean willDecode(String jsonMessage) {
		try {
			// Check if incoming message is valid JSON
			JsonObject jsonObject = Json.createReader(new StringReader(jsonMessage)).readObject();
			int messageType = jsonObject.getInt("messageType");
			if ((messageType & GenericMessage.MESSAGE_TYPE_TRACE) == 0)
				return true;
			else
				return false;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public void init(EndpointConfig ec) {
		System.out.println("MessageDecoder -init method called");
	}

	@Override
	public void destroy() {
		System.out.println("MessageDecoder - destroy method called");
	}
}

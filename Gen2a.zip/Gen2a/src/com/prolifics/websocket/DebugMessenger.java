package com.prolifics.websocket;

import java.util.logging.FileHandler;
import java.util.logging.Logger;

import javax.websocket.EncodeException;

import com.prolifics.jni.Application;
import com.prolifics.jni.CFunctionsInterface;

public class DebugMessenger extends Messenger implements TraceMessengerInterface {
	CFunctionsInterface cf;
	private final static Logger LOGGER = Logger.getLogger(DebugMessenger.class.getName());
	public static FileHandler fh;
	/* VALUE_HOLDER is a property that the application cannot be using at the point
	 * at which we borrow it for temporary storage.
	 */
	private final static String VALUE_HOLDER = "@app()->startscreen";
	public static final String UNKNOWN_VALUE = "?";
	private GenericMessageEncoder gmEncoder;
	private GenericMessageDecoder gmDecoder;
	private TraceMessageEncoder tmEncoder;
	private TraceMessageDecoder tmDecoder;
	private boolean traceMode;
	
	public DebugMessenger(String url) {
		super(url);
		traceMode = true;
		gmDecoder = (GenericMessageDecoder)getDecoder();
		gmEncoder = (GenericMessageEncoder)getEncoder();
		tmDecoder = new TraceMessageDecoder();
		tmEncoder = new TraceMessageEncoder();
		setDecoder(tmDecoder);
		setEncoder(tmEncoder);
		cf = Application.getInstance().getCFunctions();
		debuglog("Leaving DebugMessenger constructor", null);
	}
	
	public synchronized void sendTraceMessage(String jsonTraceMessage){
		
		String message = jsonTraceMessage;
		GenericMessageInterface reply = null;	
		GenericMessageInterface clientMessage = getMessage();
	
		debuglog("Entering DebugMessenger.sendTraceMessage. traceMode is " + traceMode, null);
		/* Eat any other pending messages, for now.
		 * This could be improved later.
		 */
		while (getMessage() != null) {
			;
		}

		if (clientMessage != null  && "TraceMode".equals(clientMessage.getSubject())) {
			traceMode = "on".equals(clientMessage.getContent());
			debuglog("setting traceMode to " + traceMode, null);
		}
		if(!traceMode){
			if (!isConnectionOpen()) {
				traceMode = true;  // Allow new debug session
			} else {
				debuglog("returning from DebugMessenger.sendTraceMessage, since traceMode is " + traceMode, null);
				return;
			}
		}

		try {	
			setDecoder(tmDecoder);
			setEncoder(tmEncoder);
			debuglog("DebugMessenger: Calling super.sendSyncMessenger with message: " + message, null);
			reply = super.sendSyncMessage(message);
			
			if (reply == null) {
				debuglog("sendSyncMessage returned null after notification", null);
				return; // Prevent jserver from hanging when connection fails.
			}
		} catch (Throwable t) {
			debuglog("Failed to send notification message to client.", t);
			return;
		}
		
		while (true) {
			if (!isConnectionOpen()) {
				return;
			}
			
			try {
				debuglog("subject is" + reply.getSubject(), null);
				
				setDecoder(gmDecoder);
				setEncoder(gmEncoder);
				  if (reply == null || "NextEvent".equals(reply.getSubject()) || 
					reply.getMessageType() == GenericMessageInterface.MESSAGE_TYPE_ERROR)
				{
					break;
					
				} else if ("GetValue".equals(reply.getSubject())) {
					long millis = System.currentTimeMillis();
					GenericMessage gm = new GenericMessage();
					gm.setSubject("GetValueReply");
					gm.setMessageType(GenericMessageInterface.MESSAGE_TYPE_REPLY);
					gm.setChannelId(reply.getChannelId());
					String content = reply.getContent();
					debuglog("Calling sm_n_fptr", null);
					String valueHolderVal = cf.sm_n_fptr(VALUE_HOLDER);
					debuglog("Calling sm_calc", null);
					String value = null;
					int rv = cf.sm_calc(0, 0, VALUE_HOLDER + " = " + content);
					if (rv == 0) {
						debuglog("Calling sm_n_fptr again", null);
						value = cf.sm_n_fptr(VALUE_HOLDER);
						debuglog("Calling sm_calc again", null);
						// Put back original value into VALUE_HOLDER
						cf.sm_calc(0, 0, VALUE_HOLDER + " = " + valueHolderVal);

					}
					if (value == null || rv != 0) {
						value = UNKNOWN_VALUE;
					} else {
						value = "\"" + value + "\"";
					}
					debuglog("value is: " + value + "time=" + (System.currentTimeMillis() - millis) + "ms", null);
					gm.setContent(content + "==" + value);
					debuglog("about to encode reply message", null);
					message = gmEncoder.encode(gm);
					debuglog("encoded reply message", null);
				} else if ("SetValue".equals(reply.getSubject())) {
					GenericMessage gm = new GenericMessage();
					gm.setSubject("SetValueReply");
					gm.setMessageType(GenericMessageInterface.MESSAGE_TYPE_REPLY);
					gm.setChannelId(reply.getChannelId());
					String content = reply.getContent();
					int iEq = content.indexOf("=");
					String var;
					if (iEq <= 0) {
						gm.setMessageType(gm.getMessageType() | GenericMessageInterface.MESSAGE_TYPE_ERROR);
						message = gmEncoder.encode(gm);
						continue;
					}

					// Perform the assignment; depends on sm_setinjpl(1)
					int rv = cf.sm_calc(0, 0, content);
					if (rv != 0) {
						debuglog("sm_calc failed to perform assignment", null);
					}
					
					// Get the new value that was set
					var = content.substring(0, iEq);
					String valueHolderVal = cf.sm_n_fptr(VALUE_HOLDER);
					debuglog("Calling sm_calc", null);
					String value = null;
					rv = cf.sm_calc(0, 0, VALUE_HOLDER + " = " + var);
					if (rv == 0) {
						debuglog("Calling sm_n_fptr again", null);
						value = cf.sm_n_fptr(VALUE_HOLDER);
						debuglog("Calling sm_calc again", null);
						// Put back original value into VALUE_HOLDER
						cf.sm_calc(0, 0, VALUE_HOLDER + " = " + valueHolderVal);

					}
					if (value == null || rv != 0) {
						value = UNKNOWN_VALUE;
					} else {
						value = "\"" + value + "\"";
					}
					debuglog("value is: " + value, null);
					gm.setContent(var + "==" + "\"" + value + "\"");
					debuglog("about to encode reply message", null);
					message = gmEncoder.encode(gm);
					debuglog("encoded reply message", null);
							
				/*
					String value = cf.sm_n_fptr(VALUE_HOLDER);
					cf.sm_calc(0, 0, VALUE_HOLDER + " = " + var);			
					gm.setContent(var + "==" + cf.sm_n_fptr(VALUE_HOLDER));
					cf.sm_calc(0, 0, VALUE_HOLDER + " = " + value);	
					message = gmEncoder.encode(gm);
				*/	
				} else if ("TraceMode".equals(reply.getSubject())){
					traceMode = "on".equals(reply.getContent());
					debuglog("DebugMessenger: Received TraceMode message.  Setting traceMode to " +
							traceMode + " and returning.", null);
					return;	// No reply to send
				} else {
					debuglog("DebugMessenger: Unknown message with subject: " + reply.getSubject() + 
							".  Returning.", null);
					return;
				}
				debuglog("Ready to send reply back to the client", null);
				reply = super.sendSyncMessage(message);
				/* Eat any other pending messages, for now.
				 * This could be improved later.
				 */
				while (getMessage() != null) {
					;
				}

				debuglog("Sent reply back to the client", null);
				
			} catch (EncodeException ee) {
				LOGGER.warning("Unable to encode reply message to client.");
				debuglog("Unable to encode reply message to client.", ee);
				continue;
			} catch (Throwable t) {
				debuglog("Failed to send reply message to client.", t);
				return;
			} finally {
				setDecoder(tmDecoder);
				setEncoder(tmEncoder);
			}
		}
		debuglog("Returning to Panther: message=" + message, null);
		return;
	}
}
package com.prolifics.websocket;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EncodeException;
import javax.websocket.Encoder;


public class Messenger implements MessengerInterface {

	private MessengerEndpoint messengerEndpoint = null;
	GenericMessageInterface pMessage = null;
	String url;
	String channelId;
	MessengerEndpoint.MessageHandler messageHandler;
	private Decoder.Text<?> decoder;
	private Encoder.Text<?> encoder;
	
	private final static Logger LOGGER = Logger.getLogger(Messenger.class.getName());
	
	public static FileHandler fh;
	Object lock = new Object(); // protect sMessage and coordinate duplex use of websocket
	PrintWriter pw;
	ArrayList<GenericMessageInterface> msgList;
	boolean debug = false;
	
	public Messenger() {
		this(null);
	}
	public Messenger(String url) {
		
		/* Set the url, but don't open the connection yet.  Panther may wish to
		 * open the connection later, after changing the url for this instance.
		 */
		this.url = url;
		msgList = new ArrayList<GenericMessageInterface>();
		setDecoder(new GenericMessageDecoder());
		setEncoder(new GenericMessageEncoder());
		String loggingProperties = System.getProperty("java.util.logging.config.file");
		debuglog("java.util.logging.config.file=" + loggingProperties, null);
		messageHandler = new MessengerEndpoint.MessageHandler() {
			@Override
			public void handleMessage(String message) {
												
				LOGGER.log(Level.FINEST, "Client message=" + message);
				debuglog("in handleMessage(String) - waiting to acquire lock", null);
				synchronized(lock) {
					debuglog("in handleMessage(String) - lock acquired", null);
					try{
						pMessage = (GenericMessage)decoder.decode(message);
						msgList.add(pMessage);
					}
					catch(Exception e){
						pMessage = null;
						throw new MessengerException(e);
					}	
					LOGGER.finest("in handleMessage(String) - notifying other thread");
					debuglog("in handleMessage(String) - notifying other thread", null);
					lock.notifyAll();	// Doesn't seem to work	
				}  // end synchronized(lock)
				debuglog("leaving handleMessage()", null);
			}
		};
	}
	public void closeConnection() {
		if (isConnectionOpen()) {
			messengerEndpoint.closeConnection();
		}
	}
	
	public boolean isConnectionOpen() {
		return (messengerEndpoint != null && messengerEndpoint.isConnectionOpen());
	}
	
	public synchronized void openConnection (String url, String channelId) {
		try {
			debuglog("In openConnection: url=" + url + ", channelId=" + channelId, null);
			if ("default".equals(url) || channelId == null) {
				return;
			}
			URI targetUri = new URI(url + "?channelId=" + channelId + "&openLast=true");
			/* isConnectionOpen will block until the endpoint's onMessage function exits */
			URI oldUri = isConnectionOpen() ? messengerEndpoint.getUserSession().getRequestURI() : null;
			
			if (targetUri.equals(oldUri)) {
				debuglog("reusing open connection", null);
				LOGGER.fine("Reusing open connection");
				return;
			}
			if (isConnectionOpen()) {
				try {
					/* I know of no way to tell if the session is busy.  Even a synchronized onMessage
					 * handler would not do, since it may have just completed that call, but still be doing
					 * some processing.  Therefore, we sleep here for a bit to avoid a possible exception.
					 */
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// No reason to do anything here
				}
			}
			closeConnection();	// Must close old connection first
			// open websocket
			messengerEndpoint = new MessengerEndpoint(targetUri);

			// add listener
			messengerEndpoint.addMessageHandler(messageHandler);
			this.url = url;
			this.channelId = channelId;
			LOGGER.info("Connection opened for " + targetUri.toString());
		} catch (URISyntaxException ex) {
		    debuglog("URISyntaxException: ", ex);
			throw new MessengerException(ex);
		}
		return;
	}
	
	public synchronized void sendAsyncMessage(String jsonPantherMessage){
		try {
			GenericMessageInterface message = (GenericMessageInterface)decoder.decode(jsonPantherMessage);
			sendAsyncMessage(message);
		} catch (DecodeException e) {
			throw new MessengerException(e);
		}
		return;
	}
	
	public synchronized void sendAsyncMessage(GenericMessageInterface message){
		try {
			/* Open connection here, in case it was never opened.  Reduces JNI
			 * overhead from Panther and allows late binding to a channel.
			 */
			openConnection(url, message.getChannelId());
			if (!isConnectionOpen()) {
				return;
			}
			
			message.setMessageType(message.getMessageType() | GenericMessageInterface.MESSAGE_TYPE_ASYNC);
			@SuppressWarnings("unchecked")
			String jsonMsg = ((Encoder.Text<GenericMessageInterface>)encoder).encode(message);
				
			LOGGER.log(Level.INFO, "Client json=" + jsonMsg);
			debuglog("Sending async message", null);
			messengerEndpoint.sendAsyncMessage(jsonMsg);

		} catch (EncodeException ee) {
		    debuglog("WebSocketRuntimeException: ", ee);
			throw new MessengerException(ee);
		}
		debuglog("returning pMessage: " + pMessage + "subject: " + pMessage.getSubject(), null);
		return;
	}
	
	public synchronized GenericMessageInterface sendSyncMessage(String jsonPantherMessage){
			GenericMessageInterface reply = null;
			try {
				GenericMessageInterface message = (GenericMessageInterface)decoder.decode(jsonPantherMessage);
				reply = sendSyncMessage(message);
			} catch (DecodeException e) {
				throw new MessengerException(e);
			}
			return reply;
	}

	public synchronized GenericMessageInterface sendSyncMessage(GenericMessageInterface message){
						
		GenericMessageInterface reply = null;
		try {
			/* Open connection here, in case it was never opened.  Reduces JNI
			 * overhead from Panther and allows late binding to a channel.
			 */
			if (message.getChannelId() == null) {
				return null;
			}
			openConnection(url, message.getChannelId());
			if (!isConnectionOpen()) {
				return null;
			}
			
			synchronized(lock) {
				pMessage = null;
				@SuppressWarnings("unchecked")
				String jsonMsg = ((Encoder.Text<GenericMessageInterface>)encoder).encode(message);
				
				LOGGER.log(Level.INFO, "Client json=" + jsonMsg);
				debuglog("Sending message", null);
				messengerEndpoint.sendSyncMessage(jsonMsg);
				
				/* Wait until notified by handleMessage().
				 * It seems to always wait the full timeout.
				 * I don't know why.
				 */
				debuglog("waiting for lock release", null);
			    while (pMessage == null) {
			    	lock.wait(5000);
			    	if (!isConnectionOpen()) {
			    		break;
			    	}
			    }
			    reply = getMessage();
			    debuglog("lock released", null);
				System.out.println("sendSyncMessage Completed");
					
			}
			// closeConnection();

		} catch (InterruptedException e) {
		    debuglog("InterruptedException: ", e);
			throw new MessengerException(e);
		} catch (EncodeException ee) {
		    debuglog("WebSocketRuntimeException: ", ee);
			throw new MessengerException(ee);
		}
		if (pMessage != null) {
			debuglog("sendSyncMessage returning message with subject: " + pMessage.getSubject(), null);
		} else {
			debuglog("sendSyncMessage returning.  Connection was closed.", null);
		}
		return reply ;
		
	}
	
	public GenericMessageInterface getMessage() {
	    GenericMessageInterface msg = null;
	    synchronized(lock) {
	        msg = pMessage;
	        if (!msgList.isEmpty()) {
	            msgList.remove(pMessage);
	        }
	        pMessage = null;
	        if (!msgList.isEmpty()) {
	            pMessage = msgList.get(msgList.size()-1);
	        }
	    }
	    return msg;
	}
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Decoder getDecoder() {
		return decoder;
	}
	public void setDecoder(Decoder.Text<?> decoder) {
		this.decoder = decoder;
	}
	public Encoder getEncoder() {
		return encoder;
	}
	public void setEncoder(Encoder.Text<?> encoder) {
		this.encoder = encoder;
	}

	// This is needed because of difficulty in getting Java logging to work in Panther
	protected void debuglog(String logmsg, Throwable t) {
		if (!debug) {
			return;
		}
		if (pw == null) {
			try {
				FileOutputStream out = new FileOutputStream(new File("debug.log"));
				pw = new PrintWriter(out);
			} catch (FileNotFoundException fnfe) {
				throw new RuntimeException(fnfe);
			}
		}
		pw.println(logmsg);
		if (t != null) {
			t.printStackTrace(pw);
		}
		pw.flush();
	}
}


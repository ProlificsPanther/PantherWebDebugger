package com.prolifics.websocket;

import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonObject;
import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;

public class TraceMessageDecoder implements Decoder.Text<GenericMessageInterface> {

	@Override
	public GenericMessageInterface decode(String jsonMessage) throws DecodeException {

		System.out.println("TraceMessageDecoder: " + jsonMessage);

		GenericMessageInterface message;

  		JsonObject jsonObject = Json
				.createReader(new StringReader(jsonMessage)).readObject();
				
		int messageType = jsonObject.getInt("messageType");
		if ((messageType & GenericMessageInterface.MESSAGE_TYPE_TRACE) != 0) {
			TimeStamp tm = new TimeStamp();
			tm.setHour(jsonObject.getJsonObject("tm").getInt("hour"));
			tm.setMin(jsonObject.getJsonObject("tm").getInt("min"));
			tm.setSec(jsonObject.getJsonObject("tm").getInt("sec"));
			TraceMessage traceMessage = new TraceMessage();
			message = traceMessage;
			
			traceMessage.setTm(tm);
			traceMessage.setWidgetId(jsonObject.getInt("widgetId"));
			traceMessage.setFormSerial(jsonObject.getInt("formSerial"));
			traceMessage.setWhy(jsonObject.getInt("why"));
			traceMessage.setValue(jsonObject.getInt("value"));
			traceMessage.setVerb(jsonObject.getInt("verb"));

		} else {

			GenericMessage genericMessage = new GenericMessage();
			message = genericMessage;
		}
		message.setChannelId(jsonObject.getString("channelId"));
		message.setMessageType(messageType);
		message.setSubject(jsonObject.getString("subject"));
		message.setContent(jsonObject.getString("content"));

		System.out.println("TraceMessageDecoder: decoded");
		return message;

	}

	@Override
	public boolean willDecode(String jsonMessage) {
		try {
			// Check if jsonMessage is valid JSON for a GenericMessageInterface
			JsonObject jsonObject = Json.createReader(new StringReader(jsonMessage)).readObject();
			int messageType = jsonObject.getInt("messageType");
			String channelId = jsonObject.getString("channelId");
			if (messageType > 0 && channelId != null)
				return true;
			else
				return false;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public void init(EndpointConfig ec) {
		System.out.println("MessageDecoder -init method called");
	}

	@Override
	public void destroy() {
		System.out.println("MessageDecoder - destroy method called");
	}

}
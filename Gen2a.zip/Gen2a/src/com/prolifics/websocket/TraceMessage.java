package com.prolifics.websocket;

public class TraceMessage extends GenericMessage {

	TimeStamp tm;
	int widgetId;
	int formSerial;
	int why;
	int value;
	int verb;
	
	public TraceMessage() {
		super();
		tm = new TimeStamp();
		formSerial = -1;
		why = -1;
		value = -1;
		verb = -1;
	}
	
	public TraceMessage(String userid, TimeStamp tm, 
			int formSerial, int why, int value, int verb, int messageType, String text) {
		this.setChannelId(userid);
		this.tm = tm;
		this.formSerial = formSerial;
		this.why = why;
		this.value = value;
		this.verb = verb;
		this.setMessageType(messageType);
		this.setContent(text);
	}

	public TimeStamp getTm() {
		return tm;
	}
	public void setTm(TimeStamp tm) {
		this.tm = tm;
	}
	public int getWidgetId() {
		return widgetId;
	}

	public void setWidgetId(int widgetId) {
		this.widgetId = widgetId;
	}

	public int getFormSerial() {
		return formSerial;
	}
	public void setFormSerial(int formSerial) {
		this.formSerial = formSerial;
	}
	public int getWhy() {
		return why;
	}
	public void setWhy(int why) {
		this.why = why;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public int getVerb() {
		return verb;
	}
	public void setVerb(int verb) {
		this.verb = verb;
	}
}

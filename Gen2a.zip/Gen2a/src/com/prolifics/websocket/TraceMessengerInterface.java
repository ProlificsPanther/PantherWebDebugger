package com.prolifics.websocket;

public interface TraceMessengerInterface {
	public void sendTraceMessage(String jsonTraceMessage);
}

package com.prolifics.websocket;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.websocket.CloseReason;
import javax.websocket.CloseReason.CloseCode;
import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;



@ServerEndpoint(value = "/websocketendpoint", encoders = { TraceMessageEncoder.class, GenericMessageEncoder.class }, decoders = { TraceMessageDecoder.class })
public class Server {

	static Multicast multicast = new Multicast();
//	static {
//		synchronized (ProlificsHttpServlet.class) {
//			ProlificsHttpServlet.lock = new ReentrantLock();
//			ProlificsHttpServlet.lockCondition = ProlificsHttpServlet.lock.newCondition();
//		}
//	}
//	
//	public Server() {
//		System.out.println("Server: acquiring lock in constructor...");
//		ProlificsHttpServlet.lock.lock();
//	}
	
	@OnMessage
	public void onMessage(GenericMessageInterface message, Session session) throws EncodeException {

		//System.out.println("Server: acquiring lock in onMessage...");
		// ProlificsHttpServlet.lock.lock();
		
		// Get channel id from message
		String channelId = message.getChannelId();
		
		boolean isAsync = ((message.getMessageType() & GenericMessageInterface.MESSAGE_TYPE_ASYNC) == 
				GenericMessageInterface.MESSAGE_TYPE_ASYNC);

		Multicast.Channel channel = multicast.addSession(channelId, session);
		System.out.println("Server received message: " + message);
		
		if (channel.size() == 1 && isAsync ) {
			try {
				System.out.println("Server says: No target for WebSocket message.");
				GenericMessageInterface errresponse = message.getClass().newInstance();
				errresponse.setChannelId(message.getChannelId());
				errresponse.setMessageType(GenericMessageInterface.MESSAGE_TYPE_ERROR);
				errresponse.setSubject("TraceReply");
				errresponse.setContent("ERROR: Cannot find target session for WebSocket message.");
				session.getBasicRemote().sendObject(errresponse);
				// session.getAsyncRemote().sendObject(errresponse);
				// session.getBasicRemote().sendText(new GenericMessageEncoder().encode(errresponse));
				System.out.println("Server says: Sent error reply.");
				
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (IOException ioe) {
				System.out.println("Caught IOException");
				ioe.printStackTrace();
				Throwable[] suppressed = ioe.getSuppressed();
				for (int i = 0; i < suppressed.length; i++) {
					System.out.print("Suppressed[" + i + "] : ");
					suppressed[i].printStackTrace();
				}			
			}
		} else {
			Iterator<Session> it = channel.iterator();
			int i = 0;
			while (it.hasNext()) {
				Session target = it.next();
				if (!target.equals(session)) {
					// target.getAsyncRemote().sendObject(message);
					try {
						if (target.isOpen()) {
							if (isAsync) {
								target.getAsyncRemote().sendObject(message);
							} else {
								target.getBasicRemote().sendObject(message);
							}
							System.out.println(i + " Sent message to: " + target.getId());
						} else {
							System.out.println("Target " + i + " is no longer open.  Removing from channel.");
							channel.removeSession(target);
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		/* If we're about to return to Panther, allow Panther's time-sensitive
		 * operations to begin.
		 */ 
		/*
		if ("NextEvent".equals(message.getSubject())) {
			synchronized(ProlificsHttpServlet.class) {
				try {
					System.out.println("Server: calling await() to release lock...");
					ProlificsHttpServlet.lockCondition.await();
					System.out.println("Server: returned from await(); lock reaquired");
				} catch (InterruptedException e1) {
					; // just continue;
				}
			}
		}
		*/
	}

	@OnOpen
	public void onOpen(Session session) {
		System.out.println("Server says Client connected");
		System.out.println("maxIdleTimeout=" + session.getMaxIdleTimeout());
		String sQuery = session.getQueryString();
		if (sQuery != null) {
			Map<String, String> qmap = getQueryMap(sQuery);
			String channelId = qmap.get("channelId");
			String openLast = qmap.get("openLast");
			Multicast.Channel channel = multicast.getChannel(channelId);
			if (channel == null && "true".equals(openLast)) {
				throw new IllegalStateException("This session, " + session + ", must not be the first in a new multicast channel.");
			}
			if ((channel == null && "true".equals(openLast)) ||
			    (channel != null && channel.size() > 1))
			{
				if (channel == null) {
					throw new IllegalStateException("This session, " + session + ", must not be the first in a new multicast channel.");
				}
				multicast.closeChannel(channel);
			} else {
				multicast.addSession(channelId, session);
			}
		}
	}

	@OnClose
	public void onClose(Session session) {
		System.out.println("Server says Connection closed");
		System.out.println("maxBinBufSize=" + session.getMaxBinaryMessageBufferSize() + ", maxTextBufSize=" + session.getMaxTextMessageBufferSize());
		Multicast.Channel channel = multicast.removeSession(session);
		// If there are no more recipients, close the remaining connection and channel
		if (channel != null && channel.size() == 1) {
			multicast.closeChannel(channel);
		}
	}
		
	@OnError
	public void onError(Throwable e){
		System.out.println("Server says ERROR");
		System.out.println(e.getMessage());
		e.printStackTrace();
		Throwable cause = e.getCause();
		Throwable causecause;
		if (cause != null) {
			cause.getStackTrace();
			causecause = cause.getCause();
			if (causecause != null) {
				causecause.printStackTrace();
			}
		}
	}
	
	public static Map<String, String> getQueryMap(String query)  
	{  
		System.out.println("query=" + query);
		String[] params = query.split("&");
		Map<String, String> map = new HashMap<String, String>();
		for (String param : params)
		{
			String name = param.split("=")[0];
			String value = param.split("=")[1];
			map.put(name, value);
	     }
		return map;
	 }
}
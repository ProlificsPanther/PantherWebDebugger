package com.prolifics.websocket;

/*************************************/
/*  Copyright  (C)  1999 - 2014	     */
/*           by                      */
/*  Prolifics, Incorporated	     */
/*  New York, New York               */
/*  All Rights Reserved              */
/*  Printed in U.S.A.                */
/*  Confidential, Unpublished        */
/*  Property of Prolifics, Inc.	     */
/*************************************/

/* @(#)filtered.java	77.3 13/10/29 16:54:07 */

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


/**
 *
 * @version		 @(#)filtered.java	77.3 13/10/29 16:54:07
 * @author		 Prolifics
 */
@WebServlet("/Debugger")
public
class Requester extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private static final String sccsid = "%W% %E% %U%";

	public Requester() {
    	super();
    }

	public void doGet (HttpServletRequest req,
		HttpServletResponse res)
		throws ServletException, IOException
	{
		if (doDebugger(req, res)) {
			return;
		}
		super.doGet(req, res);
	}

	public void doPost (HttpServletRequest req,
		HttpServletResponse res)
		throws ServletException, IOException
	{
		if (doDebugger(req, res)) {
			return;
		}
		super.doPost(req, res);
	}
	
	private boolean doDebugger(HttpServletRequest req,
		HttpServletResponse res) 
		throws ServletException, IOException
	{
		String webSocketURL = "ws://" + req.getServerName() + ":" +
				req.getServerPort() + req.getContextPath() + "/websocketendpoint";
		
		String contextPath = req.getContextPath();
		String url = "";

		/* Set cookies for the response.  These will get sent to
		 * Panther when the iframe makes its request
		 */
		Cookie cookie1 = new Cookie("WebSocketURL", webSocketURL);
		//cookie1.setPath("/proweb");
		res.addCookie(cookie1);
		req.getSession();
		Cookie cookie2 = new Cookie("JSESSIONID", req.getSession().getId());
		//cookie2.setPath("/proweb");
		res.addCookie(cookie2);

		String queryString = req.getQueryString();
		if (queryString != null) {
			url += queryString;
		}
		// Generate HTML and Javascript

		String script = 
			"$(document).ready(function(){\n" +
					"openSocket('" + req.getSession().getId() + "', '" + webSocketURL + "');\n" +	
					"var address = document.getElementById(\"url\");\n" +
					"address.value = getCookie(\"url\");\n" +
					"});\n";

		String html = 
//				"<!DOCTYPE html>\n" +
				"<html>\n" +
					"<head>\n" +
						"<link rel=\"stylesheet\" href=\"" + contextPath + "/debugclient.css\">\n" +
						"<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>\n" +
						"<script>\n" +
							script +
						"</script>\n" +
						"<script src=\"" + contextPath + "/debugclient.js\"></script>\n" +
					"</head>\n" +
				
	                "<body onload=\"statustab();\">\n"  +
						"<div>\n" +	
							/*"<iframe id=\"pantherframe\" src=" +
								"\"" + url + "\"" +
								">\n" +
							"<p>Your browser does not support iframes.</p>\n" +
							"</iframe>\n" +*/
						"</div>" +
							
						"<div id=\"floatdiv\">\n" +
						
						"</div>\n" +
						
						"<div id=\"debugUI\">\n" +
							"<div class=\"controlbtns\">\n"  +
								"<span>&nbsp;&nbsp;&nbsp;</span>" +
								"<button type=\"button\" id=\"toBreakpointbtn\" onclick=\"nextBreak();\" title=\"Continue to next breakpoint\" disabled></button>\n" +
								"<button type=\"button\" id=\"sendNextbtn\" onclick=\"nextEvent();\" title=\"Step in/Continue to next event\" disabled></button>\n" +
								"<button type=\"button\" id=\"stepOverbtn\" onclick=\"stepOver();\" title=\"Step over\" disabled></button>\n" +
								"<button type=\"button\" id=\"breakbtn\" onclick=\"doBreak();\" title=\"Break at next event\" disabled></button>\n" +
								"<button type=\"button\" id=\"sdebug\" onclick=\"toggleDebugMode();\" title=\"Toggle Debug Mode\" ></button>\n" +
								"<button type=\"button\" id=\"cleanup\" onclick=\"clearTrace();\" title=\"Clear Log\" ></button>\n" +
								"<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Application URL: </span><input type=\"text\" id=\"url\" style=\"width:20%;\" value=\"" + url + "\"" +
									"onkeypress=\"urlEnter(event);\"></input>" +
								"<button type=\"button\" id=\"goToUrl\" onclick=\"doGoToUrl();\" title=\"Go\">Go</button>\n" +
							"</div>\n" +	

"<div class=\"tab\">"+
								"<div id=\"tabgroup1\">"+
									// "<button class=\"tablinks1\" id=\"statustab\" title=\"Status tab\" onclick=\"opentab1(event, 'Statuswindow');\">Status</button>"+
									"<button class=\"tablinks1\" id=\"statustab\" title=\"Status tab\">Status</button>"+
								"</div>"+
								"<div id=\"tabgroup2\">"+
									"<button class=\"tablinks1\" id=\"breakpointstab\" title=\"Breakpoints tab\" onclick=\"opentab1(event, 'Breakpoints');\">Breakpoints</button>"+
									"<button class=\"tablinks1\" id=\"datawatchtab\" title=\"Datawatch tab\" onclick=\"opentab1(event, 'Datawatch');\">Data Watch</button>"+
									"<button class=\"tablinks1\" id=\"jplstacktab\" title=\"Jplstack tab\" onclick=\"opentab1(event, 'Jplstack');\">Jpl Stack</button>"+
								"</div>"+
"</div>"+									
								// "<div id=\"Statuswindow\" class=\"tabcontent1\" onmouseover=\"statusHover(event);\">"+
								"<div id=\"Statuswindow\" onmouseover=\"statusHover(event);\">"+
									"<div contenteditable=\"false\" disabled id=\"events\"><word id=\"gs\">Debugger</word> <word>Started</word><br></div>" +
								"</div>"+
								"<div id=\"Breakpoints\" class=\"tabcontent1\">"+
									"<table cellspacing=\"0\" width=\"100%\" bgcolor=#cccccc>"+
						        		"<thead>"+
						            		"<tr id=\"head\">"+
						            			"<th><center>Type</center></th>"+
						            			"<th><center>Module Name</center></th>"+
						            			"<th><center>Location</center></th>"+
						            		"</tr>"+
						            	"</thead>"+
						            "</table>"+
						            "<div id=\"brkpt\">"+
						            	"<table id=\"table\" class=\"display\" cellspacing=\"0\" width=\"100%\">"+
						            		"<tbody>"+
						            			"<tr id='one'>"+
						            				"<td>"+
						            					"<select id=\"type1\" name=\"options\" style=\"width:100%;\">"+
						            						"<option value=\"1\">Any JPL</option>"+
						            						"<option value=\"2\">JPL Module</option>"+
						            						"<option value=\"3\">Screen Entry</option>"+
						            						"<option value=\"4\">Screen Exit</option>"+
						            						"<option value=\"5\">Field Entry</option>"+
						            						"<option value=\"6\">Field Exit</option>"+
						            						"<option value=\"7\">Key</option>"+
						            						"<option value=\"8\" selected>Unused</option>"+	
						            					"</select>"+
						            				"</td>"+
										
								  					"<td scope=\"col\">"+
								  						"<input id=\"modName1\" type=\"text\" name=\"module1\" style=\"width:100%;\">"+
								  					"</td>"+
								  					"<td scope=\"col\">"+
								  						"<input type=\"text\"  id=\"location1\" name=\"location1\" onkeypress=\"textcheck(event,'location1');\" style=\"width:100%;\">"+
								  					"</td>"+
								  				"</tr>"+
								  				"<tr id='two' style=\"width:100%;\">"+
													"<td>"+
														"<select id=\"type2\" name=\"options\" style=\"width:100%;\">"+
														"<option value=\"1\">Any JPL</option>"+
					            						"<option value=\"2\">JPL Module</option>"+
					            						"<option value=\"3\">Screen Entry</option>"+
					            						"<option value=\"4\">Screen Exit</option>"+
					            						"<option value=\"5\">Field Entry</option>"+
					            						"<option value=\"6\">Field Exit</option>"+
					            						"<option value=\"7\">Key</option>"+
					            						"<option value=\"8\" selected>Unused</option>"+	
														"</select>"+
													"</td>"+
		
													"<td scope=\"col\">"+
														"<input name=\"module2\" id=\"modName2\" type=\"text\" style=\"width:100%;\">"+
													"</td>"+
													"<td scope=\"col\">"+
														"<input type=\"text\"  id=\"location2\" name=\"location2\" onkeypress=\"textcheck(event,'location2');\" style=\"width:100%;\">"+
													"</td>"+
												"</tr>"+
											"</tbody>"+
										"</table>"+
										"<input type=\"button\" value=\"Add Row\" onclick=\"addRow('event');\" />"+
									"</div>"+	// brkpt
										
								"</div>"+	// Breakpoints
								"<div id=\"Datawatch\" class=\"tabcontent1\">"+
								// "<div id=\"Datawatch\">"+
									
									"<table cellspacing=\"0\" width=\"100%\" bgcolor=#cccccc>"+
									"<col width=30%>"+
									"<col width=70%>"+
										"<thead>"+
											"<tr>"+
												"<th><center>Variables & Expressions</center></th>"+
												"<th><center>Values</center></th>"+
											"</tr>"+
										"</thead>"+
									"</table>"+
									"<div id=\"datawatchtable\">"+
						        		"<table id=\"example\" class=\"display\" cellspacing=\"0\" width=\"100%\">"+
						        			"<col width=30%>"+
						        			"<col width=70%>"+     
						        			"<tr>"+
						        			"<td>"+     	
						         				"<input type=\"text\" id=\"varexp0\" class=\"varexp\" onkeypress=\"datawatchvar(event);\" style=\"width:100%;\"></input>"+
						         			"</td>"+
						         			"<td>"+		
						         				"<input type=\"text\" id=\"values0\" class=\"values\" onkeypress=\"datawatchval(event)\" style=\"width:100%;\"></input>"+		
						         			"</td>"+
						         		"</tr>"+
						         		"<tr>"+
						         			"<td>"+
						         				"<input type=\"text\" id=\"varexp1\" class=\"varexp\" onkeypress=\"datawatchvar(event);\" style=\"width:100%;\"></input>"+
						         			"</td>"+
						         			"<td>"+
						         				"<input type=\"text\" id=\"values1\" class=\"values\" onkeypress=\"datawatchval(event)\" style=\"width:100%;\"></input>"+
						         			"</td>"+
						         		"</tr>"+
						         		"<tr>"+
						         			"<td>"+
						         				"<input type=\"text\" id=\"varexp2\" class=\"varexp\" onkeypress=\"datawatchvar(event);\" style=\"width:100%;\" ></input>"+
						         			"</td>"+
						         			"<td>"+
						         				"<input type=\"text\" id=\"values2\" class=\"values\" onkeypress=\"datawatchval(event)\" style=\"width:100%;\"></input>"+
						         			"</td>"+
						         		"</tr>"+
						         		"<tr>"+
						         			"<td>"+
						         				"<input type=\"text\" id=\"varexp3\" class=\"varexp\" style=\"width:100%;\" onkeypress=\"datawatchvar(event);\"></input>"+
						         			"</td>"+
						         			"<td>"+
						         				"<input type=\"text\" id=\"values3\" class=\"values\" onkeypress=\"datawatchval(event)\" style=\"width:100%;\"></input>"+
						         			"</td>"+
						         		"</tr>"+
						         	"</table>"+
						        "</div>"+"</div>"+	// Datawatch
						       
"<div id=\"Jplstack\" class=\"tabcontent1\">"+
// "<div id=\"JPLSTACK\">"+
	
	"<table cellspacing=\"0\" width=\"100%\" bgcolor=#cccccc>"+
	
	"<col width=50%>"+
		"<thead>"+
			"<tr>"+
				"<th><center>JPL Module</center></th>"+
				
			"</tr>"+
		"</thead>"+
	"</table>"+
	"<div id=\"jpltable\">"+
		"<table id=\"example\" class=\"display\" cellspacing=\"0\" width=\"100%\">"+
			
			"<col width=70%>"+     
			"<tr>"+
			"<td>"+     	
 				"<input type=\"text\" id=\"jplFileName\" class=\"varexp\"  style=\"width:100%;\"></input>"+
 			"</td>"+
 			
 		"</tr>"+
 		
 	"</table>"+
"</div>"+	// JPLStack
						
						"</div>\n" +	// debugui
					"</body>\n" +
				"</html>\n";
		res.getOutputStream().println(html);
		return true;
	}
}

package com.prolifics.websocket;

public interface GenericMessageInterface {
	public static final int MESSAGE_TYPE_NOTIFICATION = 0x01;
	public static final int MESSAGE_TYPE_REPLY = 0x02;
	public static final int MESSAGE_TYPE_ERROR = 0x04;
	public static final int MESSAGE_TYPE_ASYNC = 0x08;
	public static final int MESSAGE_TYPE_TRACE = 0x1000;
	
	public String getChannelId();
	public void setChannelId(String userid);
	public int getMessageType();
	public void setMessageType(int messageType);
	public String getSubject();
	public void setSubject(String subject);
	public String getContent();
	public void setContent(String text);
}

package com.prolifics.websocket;

public class GenericMessage implements GenericMessageInterface {
	
	String channelId;
	int messageType;
	String subject;
	String content;
	
	public GenericMessage() {
		channelId = "";
		messageType = -1;
		subject = "";
		content = "";
	}
	
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String userid) {
		this.channelId = userid;
	}
	
	public int getMessageType() {
		return messageType;
	}
	public void setMessageType(int messageType) {
		this.messageType = messageType;
	}
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}
	public void setContent(String text) {
		this.content = text;
	}
}

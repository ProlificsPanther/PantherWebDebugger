package com.prolifics.websocket;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

public class TraceMessageEncoder implements Encoder.Text<TraceMessage> {

	@Override
	public String encode(TraceMessage message) throws EncodeException {

		if (!(message instanceof TraceMessage)) {
			throw new EncodeException(message, "Not an instance of " + TraceMessage.class.getName());
		}
		TraceMessage pmessage = (TraceMessage)message;
		JsonObjectBuilder builderTm = Json.createObjectBuilder();
		builderTm.add("hour", pmessage.getTm().getHour());
		builderTm.add("min", pmessage.getTm().getMin());
		builderTm.add("sec", pmessage.getTm().getSec());

		JsonObject jsonObject = Json.createObjectBuilder()
				.add("channelId", pmessage.getChannelId())
				.add("tm", builderTm.build())
				.add("widgetId", pmessage.getWidgetId())
				.add("formSerial", pmessage.getFormSerial())
				.add("why", pmessage.getWhy())
				.add("value", pmessage.getValue())
				.add("verb", pmessage.getVerb())
				.add("messageType", pmessage.getMessageType())
				.add("subject", pmessage.getSubject())
				.add("content", pmessage.getContent())
				.build();
		return jsonObject.toString();

	}

	@Override
	public void init(EndpointConfig ec) {
		System.out.println("TraceMessageEncoder - init method called");
	}

	@Override
	public void destroy() {
		System.out.println("TraceMessageEncoder - destroy method called");
	}

}
package com.prolifics.websocket;

import javax.json.Json;
import javax.json.JsonObject;
import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

public class GenericMessageEncoder implements Encoder.Text<GenericMessage> {

	@Override
	public String encode(GenericMessage message) throws EncodeException {
		JsonObject jsonObject = Json.createObjectBuilder()
				.add("channelId", message.getChannelId())
				.add("messageType", message.getMessageType())
				.add("subject", message.getSubject())
				.add("content", message.getContent())
				.build();
		return jsonObject.toString();
	}

	@Override
	public void init(EndpointConfig ec) {
		System.out.println("MessageEncoder - init method called");
	}

	@Override
	public void destroy() {
		System.out.println("MessageEncoder - destroy method called");
	}

}
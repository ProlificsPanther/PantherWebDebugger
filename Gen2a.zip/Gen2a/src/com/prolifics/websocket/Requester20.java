package com.prolifics.websocket;

/*************************************/
/*  Copyright  (C)  1999 - 2014	     */
/*           by                      */
/*  Prolifics, Incorporated	     */
/*  New York, New York               */
/*  All Rights Reserved              */
/*  Printed in U.S.A.                */
/*  Confidential, Unpublished        */
/*  Property of Prolifics, Inc.	     */
/*************************************/

/* @(#)filtered.java	77.3 13/10/29 16:54:07 */

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.prolifics.servlet.*;


/**
 *
 * @version		 @(#)filtered.java	77.3 13/10/29 16:54:07
 * @author		 Prolifics
 */
@WebServlet("/Requester20/*")
public
class Requester20 extends ProlificsHttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private static final String sccsid = "%W% %E% %U%";

	public Requester20() {
    	super();
//   	lock = Server.lock;
//    	lockCondition = Server.lockCondition;
    }
	
	class SampleFilterHttpServletRequest
		extends FilterHttpServletRequest
	{
		private HttpServletRequest req;
		
		public SampleFilterHttpServletRequest(HttpServletRequest req)
		{
			super(req);
			this.req = req;
		}

		public ServletInputStream getInputStream() throws IOException
		{
			ServletInputStream in = super.getInputStream();
			in = new FilterServletInputStream(in);
			return in;
		}

		/* you can override any portion of the request here */
		
		/* Panther's FilterHttpServletRequest class fails to implement getRequesURL,
		 * so we do it here.
		 * */
		public StringBuffer getRequestURL() {
			return req.getRequestURL();
		}
	}

	private class SampleFilterHttpServletResponse
		extends FilterHttpServletResponse
	{
		ServletOutputStream out = null;
		@SuppressWarnings("unused")
		HttpServletResponse res;
		
		public SampleFilterHttpServletResponse(HttpServletResponse res)
		{
			super(res);
			this.res = res;
		}

		public ServletOutputStream getOutputStream() throws IOException
		{
			if (out == null) {
				out = super.getOutputStream();
				out = new FilterServletOutputStream(out);
			}
			return out;
		}

		/* you can override any portion of the response here */
	}

	public void doGet (HttpServletRequest req,
		HttpServletResponse res)
		throws ServletException, IOException
	{
		req = new SampleFilterHttpServletRequest(req);
		res = new SampleFilterHttpServletResponse(res);
		if (doDebugger(req, res)) {
			return;
		}
		super.doGet(req, res);
	}

	public void doPost (HttpServletRequest req,
		HttpServletResponse res)
		throws ServletException, IOException
	{
		req = new SampleFilterHttpServletRequest(req);
		res = new SampleFilterHttpServletResponse(res);
		if (doDebugger(req, res)) {
			return;
		}
		super.doPost(req, res);
	}
	
	private boolean doDebugger(HttpServletRequest req,
		HttpServletResponse res) 
		throws ServletException, IOException
	{
		String webSocketURL = "ws://" + req.getServerName() + ":" +
				req.getServerPort() + req.getContextPath() + "/websocketendpoint";
		
		/* Set cookies for the response.  These will get sent to
		 * Panther when the iframe makes its request
		 */
		res.addCookie(new Cookie("WebSocketURL", webSocketURL));
		req.getSession();
		
		String pathinfo = req.getPathInfo();
		if (!pathinfo.startsWith("/debug/")) {
			return false;
		}
		String url = req.getRequestURL().toString();
		if (url == null) {
			System.out.println("url is null");;
		}
		int ipathinfo = url.indexOf(pathinfo);

		url = url.substring(0, ipathinfo) + url.substring(ipathinfo + 6);
		String queryString = req.getQueryString();
		if (queryString != null) {
			url += queryString;
		}
		// Generate HTML and Javascript

		String script = 
			"$(document).ready(function(){\n" +
					"openSocket('" + req.getSession().getId() + "', '" + webSocketURL + "');\n" +			        	
					"});\n";
		String html = 
//			"<!DOCTYPE html>\n" +
			"<html>\n" +
				"<head>\n" +
				"<link rel=\"stylesheet\" href=\"../../../debugclient.css\">\n" +
					"<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>\n" +
					"<script>\n" +
						script +
					"</script>\n" +
					"<script src=\"../../../debugclient.js\"></script>\n" +
					"</head>\n" +
			
				"<body>\n" +
					"<div>\n" +	
					"<iframe id=\"pantherframe\" src=" +
						"\"" + url + "\"" +
						">\n" +
						"<p>Your browser does not support iframes.</p>\n" +
					"</iframe>\n" +
					"</div>" +
					"<div id=\"debugUI\">\n" +
						"<div>\n"  +
							"<button type=\"button\" id=\"sendNextbtn\" onclick=\"sendNext();\" disabled>Next Event</button>\n" +
							"<button type=\"button\" id=\"toBreakpointbtn\" onclick=\"nextBreak();\" disabled>To Breakpoint</button>\n" +
						"</div>\n" +
							"<div class=\"tab\">"+
								"<button class=\"tablinks\" onclick=\"opentab(event, 'Statuswindow')\">Status</button>"+
								"<button class=\"tablinks\" onclick=\"opentab(event, 'Breakpoints')\">Breakpoints</button>"+
								"<button class=\"tablinks\" onclick=\"opentab(event, 'Datawatch')\">Data Watch</button>"+
							"</div>"+
							"<div id=\"Statuswindow\" class=\"tabcontent\">"+
								"<textarea disabled id=\"events\">Status\nDebugger Started\n</textarea>" +
							"</div>"+
							"<div id=\"Breakpoints\" class=\"tabcontent\">"+
							"<table id=\"table\" class=\"display\" cellspacing=\"0\" width=\"100%\">"+

					        "<thead>"+
					            "<tr id=\"head\">"+
					                "<th><center>Type</center></th>"+
					                "<th><center>Module Name</center></th>"+
					                "<th><center>Location</center></th>"+
					                "</tr>"+
					        "</thead>"+
					        "<tbody>"+
							"<tr id='one'>"+
							
							"<td>"+
					            "<select id=\"Role\" name=\"options\" style=\"width:100%;\">"+
					                "<option value=\"1\">Any JPL</option>"+
					                "<option value=\"2\">JPL Module</option>"+
					                "<option value=\"3\">screen JPL</option>"+
					                "<option value=\"4\">Field JPL</option>"+
					                "<option value=\"5\" selected>screen Entry</option>"+
					                "<option value=\"6\">screen Exit</option>"+
					                "<option value=\"7\">Field Entry</option>"+
									"<option value=\"8\">Field Exit</option>"+				
					                "</select>"+
							  "</td>"+
									
							  "<td scope=\"col\">"+
					            "<input id=\"modname1\" type=\"text\" name=\"module1\" style=\"width:100%;\">"+
					        "</td>"+
					            "<td scope=\"col\">"+
					            "<input type=\"text\"  id=\"location1\" name=\"location1\" onkeypress=\"textcheck(event,'location1');\" style=\"width:100%;\">"+
					        "</td>"+
							"</tr>"+
							"<tr id='two' style=\"width:100%;\">"+
							
							"<td>"+
							"<select id=\"Role\" name=\"options\" style=\"width:100%;\">"+
							"<option value=\"1\">Any JPL</option>"+
							"<option value=\"2\">JPL Module</option>"+
							"<option value=\"3\">screen JPL</option>"+
							"<option value=\"4\">Field JPL</option>"+
							"<option value=\"5\" selected>screen Entry</option>"+
							"<option value=\"6\">screen Exit</option>"+
							"<option value=\"7\">Field Entry</option>"+
							"<option value=\"8\">Field Exit</option>"+				
							"</select>"+
							"</td>"+
	
							"<td scope=\"col\">"+
							"<input name=\"module2\" id=\"modname2\" type=\"text\" style=\"width:100%;\">"+
							"</td>"+
							"<td scope=\"col\">"+
							"<input type=\"text\"  id=\"location2\" name=\"location2\" onkeypress=\"textcheck(event,'location2');\" style=\"width:100%;\">"+
							"</td>"+
							"</tr>"+
							"</tbody>"+
					       "</table>"+
						    "<input type=\"button\" value=\"Add Row\" onclick=\"addRow('event')\" />"+
						    		
							"</div>"+
							"<div id=\"Datawatch\" class=\"tabcontent\">"+
								
							"<div>"+
							"<table id=\"example\" class=\"display\" cellspacing=\"0\" width=\"100%\">"+
							"<col width=30%>"+
							"<col width=70%>"+
					        "<thead>"+
					            "<tr>"+
					                "<th><center>Variables & Expressions</center></th>"+
					                "<th><center>Values</center></th>"+
					              "</tr>"+
					        "</thead>"+
					         "<tr>"+
					         	"<td>"+
					         	
					         	"<input type=\"text\" id=\"varexp\" class=\"varexp\" onkeypress=\"datawatchval(event);\"></input>"+
								
								"</td>"+
								"<td>"+
								
								"<input type=\"text\" id=\"values\" class=\"values\" disabled></input>"+
								
								"</td>"+
								"</tr>"+
								"<tr>"+
					         	"<td>"+
					         	"<input type=\"text\" id=\"varexp1\" class=\"varexp\" onkeypress=\"datawatchval(event);\" style=\"width:100%;\"></input>"+
								"</td>"+
								"<td>"+
								"<input type=\"text\" id=\"values1\" class=\"values\" style=\"width:100%;\" disabled></input>"+
								"</td>"+
								"</tr>"+
								"<tr>"+
					         	"<td>"+
					         	"<input type=\"text\" id=\"varexp2\" class=\"varexp\" onkeypress=\"datawatchval(event);\" style=\"width:100%;\" ></input>"+
								"</td>"+
								"<td>"+
								"<input type=\"text\" id=\"values2\" class=\"values\" style=\"width:100%;\" disabled></input>"+
								"</td>"+
								"</tr>"+
								"<tr>"+
					         	"<td>"+
					         	"<input type=\"text\" id=\"varexp3\" class=\"varexp\" style=\"width:100%;\" onkeypress=\"datawatchval(event);\"></input>"+
								"</td>"+
								"<td>"+
								"<input type=\"text\" id=\"values3\" class=\"values\" style=\"width:100%;\" disabled></input>"+
								"</td>"+
								"</tr>"+
					           "</table>"+
					        "</div>"+
					        "</div>"+
							
					"</div>\n" +
				"</body>\n" +
			"</html>\n";
		res.getOutputStream().println(html);
		return true;
	}
}

package com.prolifics.websocket;

import java.io.IOException;
import java.net.URI;
import javax.websocket.ClientEndpoint;
import javax.websocket.CloseReason;
import javax.websocket.ContainerProvider;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;


/**
 * Client for com.prolifics.websocket.Server
 *
 */
@ClientEndpoint
public class MessengerEndpoint {

    private Session userSession = null;
    private MessageHandler messageHandler;
 
    public MessengerEndpoint(URI endpointURI) {
        try {
            WebSocketContainer container = ContainerProvider.getWebSocketContainer();
            System.out.println(endpointURI.toString());
            container.connectToServer(this, endpointURI);
    		
        } catch (Exception e) {
            throw new MessengerException(e);
        }
    }

    /**
     * Callback hook for Connection open events.
     *
     * @param userSession the userSession which is opened.
     */
    @OnOpen
    public void onOpen(Session userSession) {
        System.out.println("Client opening websocket");
        this.userSession = userSession;
    }

    /**
     * Callback hook for Connection close events.
     *
     * @param userSession the userSession which is getting closed.
     * @param reason the reason for connection close
     */
    @OnClose
    public void onClose(Session userSession, CloseReason reason) {
        System.out.println("Client closing websocket");
        this.userSession = null;
    }

    /**
     * Callback hook for Message Events. This method will be invoked when a client send a message.
     *
     * @param message The text message
     * @throws Exception 
     */
    @OnMessage
    public void onMessage(String message)  {
        if (this.messageHandler != null) {
            this.messageHandler.handleMessage(message);
        }
    }

    /**
     * register message handler
     *
     * @param msgHandler
     */
    public void addMessageHandler(MessageHandler msgHandler) {
        this.messageHandler = msgHandler;
    }

    /**
     * Send a message.
     *
     * @param string
     */
    public void sendSyncMessage(String string) {
        try {
			this.userSession.getBasicRemote().sendText(string);	
		} 
        catch (IOException e) {
			throw new MessengerException(e);
		}
    }
    
    public void sendAsyncMessage(String string) {
    	this.userSession.getAsyncRemote().sendText(string);
    }

    public void closeConnection()  {
    	try {
    		if (this.userSession.isOpen()) {
    			this.userSession.close();
    		}
    		this.userSession = null;
		} catch (IOException e) {
			throw new MessengerException(e);
		}
    }

    public boolean isConnectionOpen() {
    	return (this.userSession != null && this.userSession.isOpen());
    }
    
    public static interface MessageHandler {
        public void handleMessage(String message) ;
    }
	public Session getUserSession() {
		return userSession;
	}

	public void setUserSession(Session userSession) {
		this.userSession = userSession;
	}

}
/*************************************/
/*  Copyright  (C)  2017             */
/*           by                      */
/*  Prolifics, Incorporated          */
/*  New York, New York               */
/*  All Rights Reserved              */
/*  Printed in U.S.A.                */
/*  Confidential, Unpublished        */
/*  Property of Prolifics, Inc.      */
/*************************************/

var webSocket;
var user;
var ind = 3;	// highest row index on datawatch tab
var MESSAGE_TYPE_NOTIFICATION = 0x01;
var MESSAGE_TYPE_REPLY = 0x02;
var MESSAGE_TYPE_ERROR = 0x04;
var MESSAGE_TYPE_TRACE = 0x1000;
var gotoBreak = false;
var iDatawatch = ind+1;
var inHover = false;
var lastTimeMouseMoved;
var jsessionid;
var webSocketURL;
var contextPath;
var currJplFile = "";
var linenum;
var bInStartProc = false;
var sproc_name;
var b_sproc_name;
var isStepOver = false;
var debugMode = true;
var index=2;
var warningMessage = false;
var isClear = false;
// Used for retaining state when toggling debug mode
var saveContinuebtn;
var saveNextbtn;
var saveBreakbtn;
var saveStepbtn;
var stack = [];
var jplModule = [];

document.getElementById("sendNextbtn").disabled=false;
document.getElementById("toBreakpointbtn").disabled=false;
document.getElementById("stepOverbtn").disabled=false;
document.getElementById("breakbtn").disabled=true;

// document.getElementById("datawatchtab").click();
// document.getElementById("url").value = getCookie("url");

function getCookie(name) {
	
    function escape(s) { 
    
    return s.replace(/([.*+?\^${}()|\[\]\/\\])/g, '\\$1'); };
    var match = document.cookie.match(RegExp('(?:^|;\\s*)' + escape(name) + '=([^;]*)'));
    return match ? match[1] : null;
}

function urlEnter(e) {
	if(e.keyCode==13){
		doGoToUrl();
	}
}
function doGoToUrl() {
	var iframe = document.getElementById("pantherframe");
	var url = document.getElementById("url").value;
	var parts = url.split("//");
	if (parts.length != 2) {
		alert("ERROR: Invalid Application URL.");
		return;
	}
	parts = parts[1].split("/");
	if (parts.length < 2) {
		alert("ERROR: Invalid Application URL.");
		return;
	}
	contextPath = "/" + parts[1];
	
	document.cookie = "url=" + url + "; expires=Fri, 31 Dec 9999 23:59:59 GMT";
	webSocketURL = getCookie("WebSocketURL");
	document.cookie = "WebSocketURL=" + webSocketURL + "; path=" + contextPath;
	jsessionid = getCookie("JSESSIONID");
	document.cookie = "JSESSIONID=" + jsessionid + "; path=" + contextPath;
	
	//iframe.src = url;
	document.getElementById("sendNextbtn").disabled=false;
	document.getElementById("toBreakpointbtn").disabled=false;
	document.getElementById("stepOverbtn").disabled=false;
	document.getElementById("breakbtn").disabled=true;
	// Calling unloadPage for these events, below, doesn't seem to be heplful
	// window.onbeforeclose = unloadPage;
	// window.onbeforeunload = unloadPage;
	// iframe.contentWindow.location.reload(true);
	window.open(url);
	//var myDiv = document.getElementById("floatdiv").outerHTML;
	//var myWindow = window.open(url);
	//var doc = myWindow.document;
	//doc.open();
	//doc.write(myDiv);
	//doc.close();
}

function delete_cookie(name) {	
	document.cookie = name + "=;" + "path=" + contextPath + "; expires=Thu, 01 Jan 1970 00:00:01 GMT;";
}

function unloadPage() {
	delete_cookie("WebSocketURL");
	delete_cookie("JSESSIONID");
}

function openSocket(sessionid, url) {
	user = sessionid;
	
	if (webSocket == null || webSocket.readyState === WebSocket.CLOSED) {
		
		// webSocket = new WebSocket(url + '?user=' + user + '&browser=true');
		webSocket = new WebSocket(url + '?channelId=' + user);
		
		webSocket.onerror = function(event) {
			onError(event);
		};

		webSocket.onopen = function(event) {
			onOpen(event);
		};

		webSocket.onmessage = function(event) {
			onMessage(event);
//			document.getElementById("sendNextbtn").disabled=false;
//			document.getElementById("toBreakpointbtn").disabled=false;
			 var status=document.getElementById("events");
			status.scrollTop = status.scrollHeight;
		};
		webSocket.onclose = function(event) {
			onClose(event);
		};
	}
}
function stepOver()
{
	isStepOver = gotoBreak = bInStartProc;
	b_sproc_name = bInStartProc ? sproc_name : null;
	sendNext();
}


function clearTrace()
{
	//isClear = true;
	//alert("IN CLEAR TRACE");
	document.getElementById("events").innerHTML = "";
	
		
	}
function toggleDebugMode()
{
	var traceMode;
	
	// alert(" inside toggleDebugMode");
	debugMode = !debugMode;
	
	if (!debugMode) {
		traceMode = "off";
		saveContinuebtn = document.getElementById("toBreakpointbtn").disabled;
		document.getElementById("toBreakpointbtn").disabled = true;
		saveNextbtn = document.getElementById("sendNextbtn").disabled;
		document.getElementById("sendNextbtn").disabled = true;
		saveBreakbtn = document.getElementById("breakbtn").disabled;
		document.getElementById("breakbtn").disabled = true;
		saveStepbtn = document.getElementById("stepOverbtn").disabled;
		document.getElementById("stepOverbtn").disabled = true;
		document.getElementById("sdebug").style.background = "url('/Gen2a/bug_red_icon.png')";
		document.getElementById("sdebug").style.backgroundPosition = "center";
		document.getElementById("sdebug").style.backgroundRepeat = "no-repeat";
		currJplFile = "";
		stack = [];
	} else {
		traceMode = "on";
		document.getElementById("toBreakpointbtn").disabled = saveContinuebtn;
		document.getElementById("sendNextbtn").disabled = saveNextbtn;
		document.getElementById("breakbtn").disabled = saveBreakbtn;
		document.getElementById("stepOverbtn").disabled = saveStepbtn;
		document.getElementById("sdebug").style.background = "url('/Gen2a/bug_green_icon.png')";
		document.getElementById("sdebug").style.backgroundPosition = "center";
		document.getElementById("sdebug").style.backgroundRepeat = "no-repeat";
	}

	
	var messageType = MESSAGE_TYPE_NOTIFICATION ;
	var json = {
			"channelId" : user,
			"messageType" : messageType,
			"subject" : "TraceMode",
			"content" : traceMode,
	};
	webSocket.send(JSON.stringify(json));
}

function onMessage(event) {	
	//alert("inside on message");
	var json = JSON.parse(event.data);
	var msg = json.content;
	var sent = false;
	//document.getElementById("floatdiv").style.display = "block";
	if(warningMessage){
		document.getElementById("floatdiv").style.display = "block";
	}else {
		document.getElementById("floatdiv").style.display = "none";
	}
	
	
	/*
	var msg = 'Received event:'
		+ ' Subject: '
		+ json.subject
		+ ', Content: '
		+ json.content
		+ ', button: '
		+ json.buttoncombo
		+ ', messagetype: '
		+ json.messagetype;
	*/	
	/*
	var msg = json.content;
	if(json.subject=="GetValue"){
		alert(msg);
		return;
	}
	if(json.subject=="GetValueReply"){
		alert(msg); v
		return;
	}
	*/

	if (json.subject == "GetValue") {	// Message bounced back
		alert("ERROR: Message bouced back for: " + msg);
		return;
	} else if ((json.messageType & MESSAGE_TYPE_ERROR) === MESSAGE_TYPE_ERROR) {
		alert("ERROR: Received error message: " + msg);
		return;
	}
	
	if ((json.messageType & MESSAGE_TYPE_NOTIFICATION) === MESSAGE_TYPE_NOTIFICATION) {
		var iJplFile = msg.indexOf("file JPL info");
		var iJPL = msg.indexOf("JPL proc start");
		var iLine = msg.indexOf("JPL line");
		var iJPLend = msg.indexOf("JPL proc end");
		
		//alert(iproc);
		var lineParts;
		var line;
		//alert("IJPLFILE"+iJplFile);
		//alert("ILINE"+iLine); 
		bInStartProc = (iJPL >= 0);
		
		if(bInStartProc) {
			sproc_name =  msg.substr(iJPL + 14).trim();
			var parts = sproc_name.split("(");

			if (parts.length > 0) {
				sproc_name = parts[0];
			}
			if (sproc_name.valueOf() == "") {
				sproc_name = "<unnamed>";
			}
			if (currJPLFile != null) {
				sproc_name = currJPLFile + "," + sproc_name;
			}
			stack.push(sproc_name);
		} else if (iJPLend >= 0){			
			var eprocname = stack.pop();
			var parts = eprocname.split("(");
			if (parts.length > 0) {
				eprocname = parts[0];
			}
			if (eprocname.valueOf() == "") {
				eprocname = "<unnamed>";
			}
			parts = eprocname.split(",");
			currJPLFile = "";
			if (parts.length > 0) {
				currJPLFile = parts[0];
			}
		}
		
		if (iJplFile >= 0) {
			currJPLFile = msg.substr(iJplFile + 14).trim();
			jplModule.push(currJPLFile);
			//alert("currJPLFile"+currJPLFile);
			document.getElementById("jplFileName").value = currJPLFile ;
		} else {
			var iJplScreen = msg.indexOf("screen JPL info");
			if (iJplScreen > 0) {
				currJPLFile = msg.substr(iJplScreen + 16).trim();
				jplModule.push(currJPLFile);
			} else {
				iLine = msg.indexOf("line");
				line = msg.substr(iLine+4).trim();
				//alert(line);
				lineParts = line.split(" ");
				linenum = lineParts[0];
				
				if (lineParts.length >= 5 && lineParts[3] == "include") {
					currJPLFile = lineParts[4];
					jplModule.push(currJPLFile);
				}
			}
		}
		
		document.getElementById("events").style="color:#408000;";
//		$('#events').append(msg + '\n');
		
			$('#events').append(msg + '<br>');
			
		
		var statustxt;
//		for (var i=0; i < msg)
		//document.getElementById("gs").title=msg;
		statustab();
		iDatawatch = 0;
	} else if (json.subject == "GetValueReply") {
		if (inHover) {
			// display tooltip here
			inHover = false;
		} else {
			updateDatawatchVal(json);
			iDatawatch++;
		}
	}

	while (iDatawatch <= ind) {
		sent = requestDatawatchVal(iDatawatch);
		if (sent == true) {
			if (breakCheck(msg)) {
				gotoBreak = false;
			}
			return;
		}
		iDatawatch++;
	}
	document.getElementById("sendNextbtn").disabled=false;
	document.getElementById("toBreakpointbtn").disabled=false;
	document.getElementById("stepOverbtn").disabled=false;
	document.getElementById("breakbtn").disabled=true;
	if (gotoBreak == true) {
		if (breakCheck(msg)) {
			gotoBreak = false;
		} else {
			sendNext();
		}
	}

}

function onOpen(event) {
	$('#events').append('WebSocket connection established<br>');

}

function onClose(event) {
	$('#events').append('WebSocket connection closed<br>');

}

function onError(event) {
	$('#events').append('WebSocket Error<br>');

}

function sendNext() { 		
	var messageType = MESSAGE_TYPE_REPLY
	var json = {
			"channelId" : user,
			"messageType" : messageType,
			"subject" : "NextEvent",
			"content" : ''
		};
	document.getElementById("sendNextbtn").disabled=true;
	document.getElementById("toBreakpointbtn").disabled=true;
	document.getElementById("stepOverbtn").disabled=true;
	document.getElementById("breakbtn").disabled=false;
	webSocket.send(JSON.stringify(json));
	
	if(warningMessage){
		document.getElementById("floatdiv").style.display = "block";
	}else {
		document.getElementById("floatdiv").style.display = "none";
	}
	
	return false;
}

function doBreak() {
	warningMessage = true;
	isStepOver = false;
	gotoBreak = false;
}

function nextEvent() {
	isStepOver = false;
	gotoBreak = false;
	sendNext();
}

function nextBreak() {
	warningMessage = false;
	gotoBreak = true;
	isStepOver = false;
	sendNext();
}

function close() {
	webSocket.close();
	return;
}

function opentab1(evt, tabName) {
	opentab(evt, tabName, "1");
}

function opentab2(evt, tabName) {
	opentab(evt, tabName, "2");
}

function opentab(evt, tabName, suffix) {
	
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent" + suffix);
    for (i = 0; i < tabcontent.length; i++) {
    	tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks" + suffix);
    for (i = 0; i < tablinks.length; i++) {
    	tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "inline-block";
    evt.currentTarget.className += " active";
} 

function breakCheck(msg) {
	
	var i; 
	var procname
	var screenName;
	var fieldName;
	var val;
	var varid;
	var elmnt;
	var brType;
	var brTypeSelected;
	var parts;
	var varid_mod;
	var modName;	
	var eproc_name;
	var procParts;
	var fieldParts;
	
	
	var iJPL = msg.indexOf("JPL proc start");
	var iScreenEntry = msg.indexOf("screen entry");
	var iScreenExit = msg.indexOf("screen exit");
	var iFieldEntry = msg.indexOf("field entry");
	var iFieldExit = msg.indexOf("field exit");
	var iGetKey = msg.indexOf("getkey");
	//iproc_start = msg.indexOf("proc start");
	
	// return false;

			
	if (iJPL >= 0) {
		procname = msg.substr(iJPL + 14).trim();
		parts = procname.split("(");
	    //alert("PROCNAME=" +procname);
		//alert("PARTS=" +parts);
		if (parts.length > 0) {
			procname = parts[0];
		}
		if (procname.valueOf() == "") {
			procname = "<unnamed>";
		}
		} else if (iScreenEntry >= 0) {
		screenName = msg.substr(iScreenEntry + 14).trim();
		}
	

		else if (iScreenExit >= 0) {
			screenName = msg.substr(iScreenExit + 13).trim();
		}
		else if (iFieldEntry >= 0) {
	
			fieldName = msg.substr(iFieldEntry + 11).trim();
			fieldParts = fieldName.split(" ");
			fieldName = fieldParts[3];	
		}
		else if (iFieldExit >= 0) {
	
			fieldName = msg.substr(iFieldExit + 10).trim();
			fieldParts = fieldName.split(" ");
			fieldName = fieldParts[3];
		}
		else if (iGetKey >= 0) {
			
			keyName = msg.substr(iGetKey + 10).trim();
			keyParts = keyName.split(" ");
			keyName = keyParts[1];
			//alert("KEY NAME"+keyName);
		}
	 
		for (i = 1; i <= index; i++) {
		brType = document.getElementById("type"+i);
		brTypeSelected = brType.options[brType.selectedIndex].text;
		varid="location"+i;
		varid_mod = "modName"+i;
		elmnt = document.getElementById(varid);
		modName = document.getElementById(varid_mod);
		
			if (brTypeSelected.valueOf() == "Any JPL" && procname != null) {
			if (elmnt != null && procname.valueOf() == elmnt.value.trim().valueOf()) {
				//alert("currJPLFile"+currJPLFile);
				document.getElementById("floatdiv").style.display = "block";
				warningMessage = true;
				return true;
			}
		} else if (brTypeSelected.valueOf() == "Screen Entry" && iScreenEntry >= 0) {
			if (elmnt != null && screenName.valueOf() == elmnt.value.trim().valueOf()) {
				document.getElementById("floatdiv").style.display = "block";
				warningMessage = true;
				return true;
			}
		} else if (brTypeSelected.valueOf() == "Screen Exit" && iScreenExit >= 0) {
			if (elmnt != null && screenName.valueOf() == elmnt.value.trim().valueOf()) {
				document.getElementById("floatdiv").style.display = "block";
				warningMessage = true;
				return true;
			}
			
		} else if (brTypeSelected.valueOf() == "Field Entry" && iFieldEntry >= 0) {
			if (elmnt != null && fieldName.valueOf() == elmnt.value.trim().valueOf()) {
				document.getElementById("floatdiv").style.display = "block";
				warningMessage = true;
				return true;
			}
		} else if (brTypeSelected.valueOf() == "Field Exit" && iFieldExit >= 0) {
			if (elmnt != null && fieldName.valueOf() == elmnt.value.trim().valueOf()) {
				document.getElementById("floatdiv").style.display = "block";
				warningMessage = true;
				return true;
			}
			
		} else if (brTypeSelected.valueOf() == "Key" && iGetKey >= 0) {
			if (elmnt != null && keyName.valueOf() == elmnt.value.trim().valueOf()) {
				document.getElementById("floatdiv").style.display = "block";
				warningMessage = true;
				return true;
			}


		} else if (brTypeSelected.valueOf() == "JPL Module" && procname != null) {
			if (elmnt != null && procname.valueOf() == elmnt.value.trim().valueOf()&& modName.value.trim().valueOf()==currJPLFile) {
				//alert("currJPLFile"+currJPLFile);
				document.getElementById("floatdiv").style.display = "block";
				warningMessage = true;
				return true;
			}
		
		} else if (brTypeSelected.valueOf() == "JPL Module" && linenum != null) {
			var bline = elmnt.value.trim().valueOf();
			var iLineNum = bline.indexOf("Line");
			if (iLineNum >= 0) {
				bline = bline.substr(iLineNum + 5).trim();
				
			}
			if (elmnt != null && linenum.valueOf() == bline.valueOf() && modName.value.trim().valueOf()==currJPLFile) {
				//alert("currJPLFile"+currJPLFile);
				document.getElementById("floatdiv").style.display = "block";
				warningMessage = true;
				return true;
			}
		}	
	}
	
			if(isStepOver && b_sproc_name != null){	
			var iproc_end = msg.indexOf("JPL proc end");
			if (iproc_end >= 0) {
			procname = msg.substr(iproc_end + 12).trim();
			parts = procname.split("(");
		    //alert("PROCNAME=" +procname);
			//alert("PARTS=" +parts);
			if (parts.length > 0) {
				procname = parts[0];
			}
			if (procname.valueOf() == "") {
				procname = "<unnamed>";
			}
			if (currJPLFile != null) {
				procname = currJPLFile + "," + procname;
			}
			
			if (procname.valueOf() == b_sproc_name.valueOf()) {
				isStepOver = false;
				b_sproc_name = null;
				return true;
			}
		}
	}
		
	return false;	
}

function requestDatawatchVal(i) {
	var varexpid="varexp"+i;
	var varexp = "";
	var sent = false;
	
	elmnt = document.getElementById(varexpid);
	if (elmnt != null) {
		varexp = elmnt.value.trim().valueOf();
	}
	if (varexp.length > 0) {
		messageType = MESSAGE_TYPE_REPLY
		json = {
				"channelId" : user,
				"messageType" : messageType,
				"subject" : "GetValue",
				"content" : varexp,
		};
		webSocket.send(JSON.stringify(json));
		sent = true;
	}
	return sent;
}

function setDatawatchVal(i) {
	var varexp = "";
	var val = null;
	var sent = false;
	var assignment;	
	var varelmnt = document.getElementById("varexp"+i);
	var valelmnt = document.getElementById("values"+i);
	
	if (varelmnt != null) {
		varexp = varelmnt.value.trim().valueOf();
	}
	
	if (varexp.length > 0) {
		assignment = varexp + "=" + valelmnt.value;
		messageType = MESSAGE_TYPE_REPLY
		json = {
				"channelId" : user,
				"messageType" : messageType,
				"subject" : "SetValue",
				"content" : assignment,
		};
		webSocket.send(JSON.stringify(json));
		sent = true;
	}
	return sent;
}

function updateDatawatchVal(msg) {
	var varexpid;
	var valuesid;
	var varexp;
	var iEquals, retvar, retval;
	var oldval;
	
	if (msg != null && msg.subject == "GetValueReply") {
		iEquals = msg.content.indexOf("==");
		if (iEquals > 0) {
			retvar = msg.content.substr(0, iEquals);
			retval = msg.content.substr(iEquals + 2);
		}
	}

	for (i = 0; i <= ind; i++) {
		varexpid="varexp"+i;
		valuesid = "values"+i;
		varexp = null;
		elmnt = document.getElementById(varexpid);
		if (elmnt != null) {
			varexp = elmnt.value.trim().valueOf();
		}

		if (retvar != null && varexp != null && retvar.valueOf() == varexp) {
			oldval = document.getElementById(valuesid).value;
			if (retval != oldval) {
				document.getElementById(valuesid).style.color = "#ff0000";
			} else {
				document.getElementById(valuesid).style.color = "#000000";
			}
			document.getElementById(valuesid).value=retval;
		}
	}
}


function addRow(table) {
	index=index+1;
	var varid;
	var table = document.getElementById("table");

	var rowCount = table.rows.length;
	var row = table.insertRow(rowCount);

	varid="type"+index;
	var cell1 = row.insertCell(0);
    var element1 = document.createElement("select");
    element1.style="width:100%;"
	element1.type="select";
	element1.name="options";
	element1.setAttribute("id",varid);
	var option1 = document.createElement("option");
    option1.innerHTML = "Any JPL";
    option1.value = "1";
    element1.add(option1, null);
    var option2 = document.createElement("option");
    option2.innerHTML = "JPL Module";
    option2.value = "2";
	element1.add(option2, null);
	var option3 = document.createElement("option");
    option3.innerHTML = " Screen JPL";
    option3.value = "3";
	element1.add(option3, null);
	var option4 = document.createElement("option");
    option4.innerHTML = "Field JPL";
    option4.value = "4";
	element1.add(option4, null);
	var option5 = document.createElement("option");
    option5.innerHTML = "Screen Entry";
    option5.value = "5";
	element1.add(option5, null);
	var option6 = document.createElement("option");
    option6.innerHTML = "Screen Exit";
    option6.value = "6";
	element1.add(option6, null);
	var option7 = document.createElement("option");
    option7.innerHTML = "Field Entry";
    option7.value = "7";
	element1.add(option7, null);
	var option8 = document.createElement("option");
    option8.innerHTML = "Field Exit";
    option8.value = "8";
	element1.add(option8, null);
	var option9 = document.createElement("option");
    option9.innerHTML = "Key";
    option9.value = "9";
	element1.add(option9, null);
	var option10 = document.createElement("option");
    option10.innerHTML = "None";
    option10.value = "10";
	element1.add(option10, null);
	cell1.appendChild(element1);
	var option11 = document.createElement("option");
    option10.innerHTML = "Unused";
    option10.value = "11";
	element1.add(option11, null);
	element1.selectedIndex = 10;
	cell1.appendChild(element1);

	varid="modName"+index;
	var cell2 = row.insertCell(1);
	var element2 = document.createElement("input");
	element2.type = "text";
	element2.style="width:100%;"
	element2.name = varid;
	element2.setAttribute("id",varid);
	cell2.appendChild(element2);
	
	varid="location"+index;
    var cell3 = row.insertCell(2);
	var element3 = document.createElement("input");
	element3.type = "text";
	element3.style="width:100%;"
	element3.name = varid;
	element3.setAttribute("id",varid);
	element3.setAttribute("onkeypress","textcheck(event,\'"+varid+"\');");
	cell3.appendChild(element3);

	var brkpt=document.getElementById("brkpt");
	brkpt.scrollTop = brkpt.scrollHeight;

}


function textcheck(e,elementid){
	if(e.keyCode==13){
		var textbox;
		textbox=document.getElementById(elementid).value;
		var bool=isNaN(textbox);
		if(!bool)
		{
			document.getElementById(elementid).value="Line "+textbox;
		}	
	}
}




function datawatchvar(e) {
	if (e.keyCode == 13) {
		var varid = e.target.id;
		var i = varid.substr(6);
		var valid = "values" + i
		var varexp;

		varexp=document.getElementById(varid).value;
		document.getElementById(valid).value="?";
			
		if(parseInt(i, 10) == ind) {
			insertRow();
		}
		if (document.getElementById("sendNextbtn").disabled == false) {
			iDatawatch = 0;
			requestDatawatchVal(0);
		}
	}
}

function datawatchval(e) {
	var valid = e.target.id;
	document.getElementById(valid).style.color = "#ff0000";
	if (e.keyCode == 13) {
		var i = valid.substr(6);

		if (document.getElementById("sendNextbtn").disabled == false) {
			if (setDatawatchVal(i) == true) {
				iDatawatch = 0;
				requestDatawatchVal(0);
			}
		}
	}
}

function insertRow(){
	if(ind>3){
		styleinput();
	}
	ind=ind+1;
	var table=document.getElementById("example");
	var row=table.insertRow(table.rows.length);
	var cell1=row.insertCell(0);
	var t1=document.createElement("input");
	t1.id = "varexp";
	t1.setAttribute("onkeypress","datawatchvar(event);");
	var varid="varexp"+ind;
	t1.setAttribute("id",varid);
          
	cell1.style.width="30%";
	cell1.appendChild(t1);
	var cell2=row.insertCell(1);
	var t2=document.createElement("input");
	t2.id = "values";
	// t2.disabled=true;
	var valid="values"+ind;
	t2.setAttribute("id",valid);
	t1.setAttribute("onkeypress","datawatchval(event);");
	cell2.style.width="70%";
	cell2.appendChild(t2);
                                    
	var datawatchtable=document.getElementById("datawatchtable");
	datawatchtable.scrollTop = datawatchtable.scrollHeight; 			
}

function styleinput(){
	if(ind>=4){
		var previd="varexp"+ind;
		var prevele=document.getElementById(previd);
		prevele.style.width="100%";
		previd="values"+ind;
		prevele=document.getElementById(previd);
		prevele.style.width="100%";
	}
}

function statustab(){
	// document.getElementById("statustab").click();
	if(warningMessage){
		document.getElementById("floatdiv").style.display = "block";
	}else {
		document.getElementById("floatdiv").style.display = "none";
	}
	
	//document.getElementById("floatdiv").style.display = "block";
	document.getElementById("datawatchtab").click();
}

function getWordAtPoint(elem, x, y) {
	if(elem.nodeType == elem.TEXT_NODE) {
	    var range = elem.ownerDocument.createRange();
	    range.selectNodeContents(elem);
	    var currentPos = 0;
	    var endPos = range.endOffset;
	    while(currentPos+1 < endPos) {
	      range.setStart(elem, currentPos);
	      range.setEnd(elem, currentPos+1);
	      if(range.getBoundingClientRect().left <= x && range.getBoundingClientRect().right  >= x &&
	         range.getBoundingClientRect().top  <= y && range.getBoundingClientRect().bottom >= y) {
	        range.expand("word");
	        var ret = range.toString();
	        range.detach();
	        return(ret);
	      }
	      currentPos += 1;
	    }
/*	    
	  } else {
	    for(var i = 0; i < elem.childNodes.length; i++) {
	      var range = elem.childNodes[i].ownerDocument.createRange();
	      range.selectNodeContents(elem.childNodes[i]);
	      if(range.getBoundingClientRect().left <= x && range.getBoundingClientRect().right  >= x &&
	         range.getBoundingClientRect().top  <= y && range.getBoundingClientRect().bottom >= y) {
	        range.detach();
	        return(getWordAtPoint(elem.childNodes[i], x, y));
	      } else {
	        range.detach();
	      }
	    }
	  }
*/
	}
	 return(null);
}

function statusHover(e) {
	if (inHover != true && document.getElementById("sendNextbtn").disabled == true) {
		return;
	}
	var currentTime = new Date().getTime();
	if (lastTimeMouseMoved != null) {
		if(currentTime - lastTimeMouseMoved < 1000) {
			return;
		}
	}
	lastTimeMouseMoved = currentTime;
	var word = getWordAtPoint(e.target, e.x, e.y);
	if (word != null && word.length > 0) {
		messageType = MESSAGE_TYPE_REPLY
		json = {
				"channelId" : user,
				"messageType" : messageType,
				"subject" : "GetValue",
				"content" : word,
		};
		webSocket.send(JSON.stringify(json));
		inHover = true;
		lastTimeMouseMoved = null;
	}
}
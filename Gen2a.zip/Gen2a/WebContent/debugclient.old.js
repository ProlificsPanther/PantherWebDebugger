/*************************************/
/*  Copyright  (C)  2017             */
/*           by                      */
/*  Prolifics, Incorporated          */
/*  New York, New York               */
/*  All Rights Reserved              */
/*  Printed in U.S.A.                */
/*  Confidential, Unpublished        */
/*  Property of Prolifics, Inc.      */
/*************************************/

var webSocket;
var user;

var MESSAGE_TYPE_NOTIFICATION = 0x01;
var MESSAGE_TYPE_REPLY = 0x02;
var MESSAGE_TYPE_ERROR = 0x04;
var MESSAGE_TYPE_TRACE = 0x1000;
		
function openSocket(sessionid, url) {
	user = sessionid;
	if (webSocket == null || webSocket.readyState === WebSocket.CLOSED) {
		
		// webSocket = new WebSocket(url + '?user=' + user + '&browser=true');
		webSocket = new WebSocket(url + '?channelId=' + user);
		
		webSocket.onerror = function(event) {
			onError(event);
		};

		webSocket.onopen = function(event) {
			onOpen(event);
		};

		webSocket.onmessage = function(event) {
			onMessage(event);
		};
		webSocket.onclose = function(event) {
			onClose(event);
		};
	}
}

function onMessage(event) {		
	var json = JSON.parse(event.data);
	/*
	var msg = 'Received event:'
		+ ' Subject: '
		+ json.subject
		+ ', Content: '
		+ json.content
		+ ', button: '
		+ json.buttoncombo
		+ ', messagetype: '
		+ json.messagetype;
		*/
	var msg = 'Received event: ' + json.content;
	$('#events').append(msg + '\n');
	// document.getElementById('messages').innerHTML = msg;
	// alert("message received");		
}

function onOpen(event) {
	$('#events').append('WebSocket connection established\n');
	//alert('Connection established\n');
}

function onClose(event) {
	$('#events').append('WebSocket connection closed\n');
	//alert('Connection Closed');
}

function onError(event) {
	$('#events').append('WebSocket Error\n');
	//alert('Error');
}

function sendNext() { 
	/*
	var subject = "NextEvent";
	var content = "Continue";
	var json = {
		'user' : user,
		'subject' : subject,
		'content' : content,
		'buttoncombo' : 2,
		'messagetype' : 1,
		'from' : 1,
		'to' : 2,
		'reply' : 0
	};
	*/
	var messageType = MESSAGE_TYPE_REPLY
	var json = {
			'channelId' : user,
			'messageType' : messageType,
			'subject' : 'NextEvent',
			'content' : ''
		};

	webSocket.send(JSON.stringify(json));
	return false;
}

function close() {
	webSocket.close();
	return;
}
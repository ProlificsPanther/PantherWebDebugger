/*************************************/
/*  Copyright  (C)  2017             */
/*           by                      */
/*  Prolifics, Incorporated          */
/*  New York, New York               */
/*  All Rights Reserved              */
/*  Printed in U.S.A.                */
/*  Confidential, Unpublished        */
/*  Property of Prolifics, Inc.      */
/*************************************/

var webSocket;
var user;
var ind = 0;
var MESSAGE_TYPE_NOTIFICATION = 0x01;
var MESSAGE_TYPE_REPLY = 0x02;
var MESSAGE_TYPE_ERROR = 0x04;
var MESSAGE_TYPE_TRACE = 0x1000;
		
function openSocket(sessionid, url) {
	user = sessionid;
	if (webSocket == null || webSocket.readyState === WebSocket.CLOSED) {
		
		// webSocket = new WebSocket(url + '?user=' + user + '&browser=true');
		webSocket = new WebSocket(url + '?channelId=' + user);
		
		webSocket.onerror = function(event) {
			onError(event);
		};

		webSocket.onopen = function(event) {
			onOpen(event);
		};

		webSocket.onmessage = function(event) {
			onMessage(event);
			document.getElementById("sendNextbtn").disabled=false;
			document.getElementById("toBreakpointbtn").disabled=false;
			var status=document.getElementById("events");
			status.scrollTop = status.scrollHeight;
		};
		webSocket.onclose = function(event) {
			onClose(event);
		};
	}
}

function onMessage(event) {		
	var json = JSON.parse(event.data);
	/*
	var msg = 'Received event:'
		+ ' Subject: '
		+ json.subject
		+ ', Content: '
		+ json.content
		+ ', button: '
		+ json.buttoncombo
		+ ', messagetype: '
		+ json.messagetype;
	*/	
	var msg = json.content;
	$('#events').append(msg + '\n');
	//sendNext();

}

function onOpen(event) {
	$('#events').append('WebSocket connection established\n');

}

function onClose(event) {
	$('#events').append('WebSocket connection closed\n');

}

function onError(event) {
	$('#events').append('WebSocket Error\n');

}

function sendNext() { 
	/*
	var subject = "NextEvent";
	var content = "Continue";
	var json = {
		'user' : user,
		'subject' : subject,
		'content' : content,
		'buttoncombo' : 2,
		'messagetype' : 1,
		'from' : 1,
		'to' : 2,
		'reply' : 0
	};
	*/
	var messageType = MESSAGE_TYPE_REPLY
	var json = {
			'channelId' : user,
			'messageType' : messageType,
			'subject' : 'NextEvent',
			'content' : ''
		};
	document.getElementById("sendNextbtn").disabled=true;
	document.getElementById("toBreakpointbtn").disabled=true;
	webSocket.send(JSON.stringify(json));
	return false;
}

function close() {
	webSocket.close();
	return;
}

function opentab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
} 



var index=2;
function addRow(table) {
	index=index+1;
	var varid;
	var table = document.getElementById("table");

	var rowCount = table.rows.length;
	var row = table.insertRow(rowCount);

	var cell1 = row.insertCell(0);
    var element1 = document.createElement("select");
	element1.style="width:100%;"
	element1.type="select";
	element1.name="options";
	 var option1 = document.createElement("option");
    option1.innerHTML = "AnyJPL";
    option1.value = "1";
    element1.add(option1, null);
    var option2 = document.createElement("option");
    option2.innerHTML = "JPL Module";
    option2.value = "2";
	element1.add(option2, null);
	var option3 = document.createElement("option");
    option3.innerHTML = " Screen JPL";
    option3.value = "3";
	element1.add(option3, null);
	var option4 = document.createElement("option");
    option4.innerHTML = "Field JPL";
    option4.value = "4";
	element1.add(option4, null);
	var option5 = document.createElement("option");
    option5.innerHTML = "screen Entry";
    option5.value = "5";
	element1.add(option5, null);
	var option6 = document.createElement("option");
    option6.innerHTML = "screen Exit";
    option6.value = "6";
	element1.add(option6, null);
	var option7 = document.createElement("option");
    option7.innerHTML = "Field Entry";
    option7.value = "7";
	element1.add(option7, null);
	var option8 = document.createElement("option");
    option8.innerHTML = "Field Exit";
    option8.value = "8";
	element1.add(option8, null);
	cell1.appendChild(element1);

	varid="modname"+index;
	var cell2 = row.insertCell(1);
	var element2 = document.createElement("input");
	element2.type = "text";
	element2.style="width:100%;"
	element2.name = varid;
	element2.setAttribute("id",varid);
	cell2.appendChild(element2);
	
	varid="location"+index;
    var cell3 = row.insertCell(2);
	var element3 = document.createElement("input");
	element3.type = "text";
	element3.style="width:100%;"
	element3.name = varid;
	element3.setAttribute("id",varid);
	element3.setAttribute("onkeypress","textcheck(event,\'"+varid+"\');");
	cell3.appendChild(element3);


}


function textcheck(e,elementid){
	if(e.keyCode==13){
		var textbox;
		textbox=document.getElementById(elementid).value;
		var bool=isNaN(textbox);
		if(!bool)
		{
			document.getElementById(elementid).value="Line "+textbox;
		}	
	}
}




function datawatchval(e) {
	if(e.keyCode==13){
		var varid;
		var valid;
		if(ind==0){
		var varexp=document.getElementById("varexp").value;
		document.getElementById("values").value=varexp;
		}
		if(ind>0){
			varid="varexp"+ind;
			valid="values"+ind;
			var varexp=document.getElementById(varid).value;
			document.getElementById(valid).value=varexp;
			
			if(ind>=3){
				insertRow();
				}
			
			if(ind<3){
				ind=ind+1;
			}
					
		}
		if(ind==0){
			ind=ind+1;
		}
	}
}

function insertRow(){
			if(ind>3){
			styleinput();
			}
			ind=ind+1;
			var table=document.getElementById("example");
            var row=table.insertRow(table.rows.length);
            var cell1=row.insertCell(0);
            var t1=document.createElement("input");
                t1.id = "varexp";
                t1.setAttribute("onkeypress","datawatchval(event);");
            var varid="varexp"+ind;
                t1.setAttribute("id",varid);
          
                cell1.style.width="30%";
                cell1.appendChild(t1);
            var cell2=row.insertCell(1);
            var t2=document.createElement("input");
                t2.id = "values";
                t2.disabled=true;
                var valid="values"+ind;
                t2.setAttribute("id",valid);
                cell2.style.width="70%";
                cell2.appendChild(t2);
                                    
}
function styleinput(){
		if(ind>=4){
			var previd="varexp"+ind;
			var prevele=document.getElementById(previd);
			prevele.style.width="100%";
			previd="values"+ind;
			prevele=document.getElementById(previd);
			prevele.style.width="100%";
		}
}